# Likeastore Chrome Extention

Augments Google / Yandex search results with your likes.

# License

MIT info@likeastore.com